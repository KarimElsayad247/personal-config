#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

/**
 * Handler for the ${NAME} endpoint.
 *
 * @author Karim Elsayad
 */
public class ${NAME}Handler extends ${PARENT_HANDLER}Handler  {

    public void setHandlerArguments() {
    
    }

    @Override
    public void handle() {
    
    }

    public ${TYPE} getOutput() {
    
    }
}
