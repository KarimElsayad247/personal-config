#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")


/**
 * Sequence for the ${NAME} endpoint.
 *
 * @author Karim Elsayad
 */
public class ${NAME}Sequence extends ${PARENT_SEQUENCE}Sequence  {

    private final transient ${NAME}Handler handler = new ${NAME}Handler(); 

    public ${NAME}Sequence() {
        super();
        addHandler(handler);
    }

    public void setSequenceArguments() {
        handler.setHandlerArguments();
    }

    public ${TYPE} getSequenceOutput() {
        return handler.getOutput();
    }
}
